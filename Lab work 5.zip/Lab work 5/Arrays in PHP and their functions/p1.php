<?php
// Creating an array
$numbers = array(10, 20, 30, 40, 50);

// Printing array values
echo "Array values are:<br>";

foreach ($numbers as $value) {
    echo $value . "<br>";
}
?>